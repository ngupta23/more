# "More" Package

This is a helper package for a variety of functions as described in the Overview section below. 

# Installation

pip install more==0.0.1b5

# Overview

This is a helper package for a variety of functions
1. Extension for Pandas Dataframe (Beta version released)
2. Extension for Visualization (Beta version released)
3. Extension for Scikit-learn (TBD)

# Examples
Check out the  [examples](https://github.com/ngupta23/more/tree/master/examples) folder for details on usage
